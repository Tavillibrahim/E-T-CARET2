
*-ÜYE GİRİŞ ÇIKIŞ İŞLEMLERİ => TAMAMLANDI
*-MENÜ İŞLEMLERİ => TAMAMLANDI
*-SLİDER MODÜLÜ => TAMAMLANDI
*-KATEGORİ İŞLEMLERİ => TAMAMLANDI
*-ÜRÜN İŞLEMLERİ => TAMAMLANDI
*-Son gezilen ürünler modülü => en son bakıcaz
*-YORUM İŞLEMLERİ => TAMAMLANDI
*-SEPET İŞLEMLERİ => TAMAMLANDI
*-ÜYE HESAP İŞLEMLERİ DÜZENLEME VE ŞİFRE GÜNCELLEME => TAMAMLANDI
*-SİPARİŞ İŞLEMLERİ => TAMAMLANDI
*-ÜRÜN ÇOKLU RESİM EKLEME => TAMAMLANDI
*-ÜRÜN ARAMA İŞLEMLERİ => TAMAMLANDI
*-İLETİŞİM FORMU => TAMAMLANDI
*-SAYFALAMA => TAMAMLANDI
*-ALT KATEGORİ İŞLEMLERİ

*-ÇOK DİL MANTIĞI NEDİR?



ÖDEVLER

9.HAFTA ÖDEV
*-Sipariş Detay kısmı yapılacak. Ödeme durumu sipariş alanında gösterilecek. if ile =>

6.HAFTA ÖDEV

//TAMAMLANDI
*-ürün durumun yanına bir sutun açıp buton ekleyeceksiniz 
"Öne çıkar" => butona tıklayınca o ürün öne çıkacak ve orda buton değişecek.


//TAMAMLANDI
7.HAFTA ÖDEV
*-Admin Panele Yorum Düzenleme / Silme İşlem tabloları eklenecek
*-Yorum onaylama sistemi kurulacak

//TAMAMLANDI
*-Slider düzenle ve slider sil işlemleri




*- Hesabim.php sayfasından giriş yapan kullanıcının bilgilerini düzenlemesini sağlayın...










































































*-ÜYE GİRİŞ ÇIKIŞ İŞLEMLERİ => TAMAMLANDI
*-MENÜ İŞLEMLERİ => TAMAMLANDI
*-SLİDER MODÜLÜ => TAMAMLANDI
*-KATEGORİ İŞLEMLERİ
*-ÜRÜN İŞLEMLERİ
*-SEPET İŞLEMLERİ
*-SİPARİŞ İŞLEMLERİ
*-ÜRÜN ARAMA İŞLEMLERİ


ÖDEVLER

*-Slider düzenle ve slider sil işlemleri
*- Hesabim.php sayfasından giriş yapan kullanıcının bilgilerini düzenlemesini sağlayın...
