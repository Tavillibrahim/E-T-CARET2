﻿<?php 
include 'header.php'; 
?>

<div class="container">

	<div class="clearfix"></div>
	<div class="lines"></div>

	<!-- Slider Gelecek -->
	<?php include 'slider.php'; ?>



</div>
<div class="f-widget featpro">
	<div class="container">
		<div class="title-widget-bg">
			<div class="title-widget">Öne Çıkan Ürünler</div>
			<div class="carousel-nav">
				<a class="prev"></a>
				<a class="next"></a>
			</div>
		</div>
		<div id="product-carousel" class="owl-carousel owl-theme">

			<?php 
			$urunsor=$db->prepare("SELECT * FROM urun where urun_durum=:urun_durum and urun_onecikar=:urun_onecikar");
			$urunsor->execute(array(
				'urun_durum' => 1,
				'urun_onecikar' => 1
				));

			
			while($uruncek=$urunsor->fetch(PDO::FETCH_ASSOC)) {


					$urun_id=$uruncek['urun_id'];
					$urunfotosor=$db->prepare("SELECT * FROM urunfoto where urun_id=:urun_id order by urunfoto_sira ASC limit 1 ");
					$urunfotosor->execute(array(
						'urun_id' => $urun_id
						));

					$urunfotocek=$urunfotosor->fetch(PDO::FETCH_ASSOC);

					
				?>



				<div class="item animated bounce">
					<div class="productwrap">
						<div class="pr-img">
							<div class="hot"></div>
							<a href="urun-<?=seo($uruncek["urun_ad"]).'-'.$uruncek["urun_id"]?>"><img  src="<?php echo $urunfotocek['urunfoto_resimyol'] ?>" alt="" class="img-responsive"></a>
							<div class="pricetag blue"><div class="inner"><span>₺<?php echo $uruncek['urun_fiyat'] ?> </span></div></div>
						</div>
						<span class="smalltitle"><a href="urun-<?=seo($uruncek["urun_ad"]).'-'.$uruncek["urun_id"]?>"><?php echo $uruncek['urun_ad'] ?></a></span>
						<span class="smalldesc">Ürün Kodu.: <?php echo $uruncek['urun_id'] ?></span>
					</div>
				</div>

				<?php } ?>

			</div>
		</div>
	</div>



	<div class="container">
		<div class="row">
			<div class="col-md-9"><!--Main content-->
				<div class="title-bg">
					<div class="title">Hakkımızda Bilgi</div>
				</div>
				<p class="ct">
					<?php 
					$hakkimizdasor=$db->prepare("SELECT * FROM hakkimizda where hakkimizda_id=:id");
					$hakkimizdasor->execute(array(
						'id' => 0
						));
					$hakkimizdacek=$hakkimizdasor->fetch(PDO::FETCH_ASSOC);

					echo substr($hakkimizdacek['hakkimizda_icerik'],0,1000) ?>
				</p>

				<a href="hakkimizda" class="btn btn-default btn-red btn-sm">Devamını Oku</a>

				<div class="title-bg">
					<div class="title">En Son Eklenen Ürünler</div>
				</div>
				<div class="row prdct"><!--Products-->
				<div class="col-md-4">
						<div class="productwrap">
							<div class="pr-img">
								<a href="urun-codegen-ckl-097kl-9-7-18"><img src="dimg/urun/25327288312787525289Bilgisayar_2323042.jpg" alt="" class="img-responsive"></a>
								<div class="pricetag on-sale"><div class="inner on-sale"><span class="onsale"><span class="oldprice">₺100</span>₺50</span></div></div>
							</div>
							<span class="smalltitle"><a href="urun-codegen-ckl-097kl-9-7-18"> Codegen CKL-097KL 9,7</a></span>
							<span class="smalldesc">Item no.: 1000</span>
						</div>
					</div>
					<div class="col-md-4">
						<div class="productwrap">
							<div class="pr-img">
								<a href="urun-samsung-galaxy-note-4-19"><img src="dimg/urun/314363163330920293019697315127346.jpg" alt="" class="img-responsive"></a>
								<div class="pricetag on-sale"><div class="inner on-sale"><span class="onsale"><span class="oldprice">₺500</span>₺99</span></div></div>
							</div>
							<span class="smalltitle"><a href="urun-samsung-galaxy-note-4-19">Samsung Galaxy Note 4</a></span>
							<span class="smalldesc">Item no.: 1000</span>
						</div>
					</div>
					<div class="col-md-4">
						<div class="productwrap">
							<div class="pr-img">
								<a href="urun-lenovo-legion-y520-intel-core-i7-16"><img src="dimg/urun/238822383221529220459622405054514.jpg" alt="" class="img-responsive"></a>
								<div class="pricetag on-sale"><div class="inner on-sale"><span class="onsale"><span class="oldprice">₺6500.00</span>₺5000.00</span></div></div>
							</div>
							<span class="smalltitle"><a href="urun-lenovo-legion-y520-intel-core-i7-16">Lenovo Legion Y520 Intel Core i7</a></span>
							<span class="smalldesc">Item no.: 1000</span>
						</div>
					</div>
					<div class="col-md-4">
						<div class="productwrap">
							<div class="pr-img">
								<a href="urun-apple-ipad-wi-fi-32gb-9-7-17"><img src="dimg/urun/250702413926834301859633037484082%20(1)s.jpg" alt="" class="img-responsive"></a>
								<div class="pricetag on-sale"><div class="inner on-sale"><span class="onsale"><span class="oldprice">₺4500.00</span>₺0.01</span></div></div>
							</div>
							<span class="smalltitle"><a href="urun-apple-ipad-wi-fi-32gb-9-7-17">Apple iPad Wi-Fi 32GB 9.7</a></span>
							<span class="smalldesc">Item no.: 1000</span>
						</div>
					</div>
					<div class="col-md-4">
						<div class="productwrap">
							<div class="pr-img">
								<a href="urun-lux-deri-sapka-kk-14"><img src="dimg/urun/2124722853312022825203.jpg" alt="" class="img-responsive"></a>
								<div class="pricetag on-sale"><div class="inner on-sale"><span class="onsale"><span class="oldprice">₺195</span>₺95</span></div></div>
							</div>
							<span class="smalltitle"><a href="urun-lux-deri-sapka-kk-14">Lüx Şapka</a></span>
							<span class="smalldesc">Item no.: 1000</span>
						</div>
					</div>
					<div class="col-md-4">
						<div class="productwrap">
							<div class="pr-img">
								<a href="urun-acer-vx5-591g-56b1-intel-core-i5-15"><img src="dimg/urun/315423005328082282499629721002034.jpg" alt="" class="img-responsive"></a>
								<div class="pricetag on-sale"><div class="inner on-sale"><span class="onsale"><span class="oldprice">₺5500.00</span>₺4000.00</span></div></div>
							</div>
							<span class="smalltitle"><a href="urun-acer-vx5-591g-56b1-intel-core-i5-15">Acer VX5-591G-56B1 Intel Core i5</a></span>
							<span class="smalldesc">Item no.: 1000</span>
						</div>
					</div>
					
					
					
				</div><!--Products-->
				<div class="spacer"></div>
			</div><!--Main content-->

			<!-- Siderbar buraya gelecek -->
			<?php include 'sidebar.php' ?>
		</div>
	</div>

	<?php include 'footer.php'; ?>