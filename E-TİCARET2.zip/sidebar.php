<div class="col-md-3"><!--sidebar-->
	<div class="title-bg">
		<div class="title">Kategoriler</div>
	</div>
	
	<div class="categorybox">
		
		<ul>
			
					<?php 

//bütün kayıtları bir kereye mahsus olmak üzere listeliyoruz; daha doğrusu, bir diziye aktarmak için verileri çekiyoruz

			$query = "SELECT * FROM kategori order by kategori_id";
			$goster = $db->prepare($query);
$goster->execute(); //queriyi tetikliyor

 $toplamSatirSayisi = $goster->rowCount(); // sorgudan dönen satır sayısını öğreniyoruz
 
$tumSonuclar = $goster->fetchAll(); //DB'deki bütün satırları ve sutunları $tumSonuclar değişkenine dizi şeklinde aktarıyoruz


//alt kategorisi olmayan kategoriin sayısını öğreniyoruz:
$altKategoriSayisi = 0;
for ($i = 0; $i < $toplamSatirSayisi; $i++) {
	if ($tumSonuclar[$i]['kategori_ust'] == "0") {
		$altKategoriSayisi++;
	}
}



for ($i = 0; $i < $toplamSatirSayisi; $i++) {
	if ($tumSonuclar[$i]['kategori_ust'] == "0") {
		kategori($tumSonuclar[$i]['kategori_id'], $tumSonuclar[$i]['kategori_ad'], $tumSonuclar[$i]['kategori_ust']);
	}
}



function kategori($kategori_id, $kategori_ad, $kategori_ust) {

	global $tumSonuclar;
	global $toplamSatirSayisi;

    //kategorinin, alt kategori sayısını öğreniyoruz:
	$altKategoriSayisi = 0;
	for ($i = 0; $i < $toplamSatirSayisi; $i++) {
		if ($tumSonuclar[$i]['kategori_ust'] == $kategori_id) {
			$altKategoriSayisi++;
		}
	}
    ///////////////////////////////////////////

	?>

	<!-- Burda Başlıyoruz ana gövde -->

	<li>

		<a href="kategori-<?=seo($kategori_ad) ?>"><?php echo $kategori_ad ?></a>
		<?php 
		if ($altKategoriSayisi > 0) {
			echo "( $altKategoriSayisi )";
		}
		?>
	</a>

	<?php

    if ($altKategoriSayisi > 0) { //alt kategorisi varsa onları da listele
    	echo "<ul>";

    	for ($i = 0; $i < $toplamSatirSayisi; $i++) {

    		if ($tumSonuclar[$i]['kategori_ust'] == $kategori_id) {
    			
    			kategori($tumSonuclar[$i]['kategori_id'], $tumSonuclar[$i]['kategori_ad'], $tumSonuclar[$i]['kategori_ust']);
    		}
    	}

    	echo "</ul>";
    }
    ?>



</li> 
<!-- Burda Başlıyoruz ana gövde -->

<?php 
}
?>
		</ul>
	</div>



	<!-- Kategoriler yukarıda -->



	<div class="title-bg">
		<div class="title">Çok Sevilen Ürünler</div>
	</div>
	<div class="best-seller">
		<ul>
			<li class="clearfix">
				<a href="#"><img src="dimg/urun/238822383221529220459622405054514.jpg" alt="" class="img-responsive mini"></a>
				<div class="mini-meta">
					<a href="urun-lenovo-legion-y520-intel-core-i7-16" class="smalltitle2">Lenovo Legion Y520 Intel Core i7</a>
					<p class="smallprice2">Fiyat :₺5000.00</p>
				</div>
			</li>
			<li class="clearfix">
				<a href="#"><img src="dimg/urun/25327288312787525289Bilgisayar_2323042.jpg" alt="" class="img-responsive mini"></a>
				<div class="mini-meta">
					<a href="urun-codegen-ckl-097kl-9-7-18" class="smalltitle2">Codegen CKL-097KL 9,7</a>
					<p class="smallprice2">Fiyat : ₺50.00</p>
				</div>
			</li>
			<li class="clearfix">
				<a href="#"><img src="dimg/urun/315423005328082282499629721002034.jpg" alt="" class="img-responsive mini"></a>
				<div class="mini-meta">
					<a href="urun-acer-vx5-591g-56b1-intel-core-i5-15" class="smalltitle2">Acer VX5-591G-56B1 Intel Core i5</a>
					<p class="smallprice2">Fiyat : ₺400.00</p>
				</div>
			</li>
		</ul>
	</div>

			</div><!--sidebar-->